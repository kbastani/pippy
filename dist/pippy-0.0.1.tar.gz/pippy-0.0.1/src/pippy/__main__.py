# SPDX-FileCopyrightText: 2025-present kbastani <kbastani@realogicworks.com>
#
# SPDX-License-Identifier: MIT
import sys

if __name__ == "__main__":
    from pippy.cli import pippy

    sys.exit(pippy())
