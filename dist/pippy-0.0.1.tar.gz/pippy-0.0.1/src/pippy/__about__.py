# SPDX-FileCopyrightText: 2025-present kbastani <kbastani@realogicworks.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
